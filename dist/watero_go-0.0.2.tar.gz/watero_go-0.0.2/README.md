# Watero Go

## 介绍

* Watero Go是部署于节点的数据采集服务, 用于采集节点日志上报Watero Center
* [Watero Center](https://github.com/Qinnnnnn/Watero_Center)是一项数据接收转发投递服务

## 如何使用

### 环境配置

* Python 3.4

### 依赖配置

* requests
* psutil

### 开启服务

```bash
pip install watero_go
```
* 导入Watero_Go模块
* 配置Watero Center的公网地址以及RESTful API服务和WebSocket服务端口号
